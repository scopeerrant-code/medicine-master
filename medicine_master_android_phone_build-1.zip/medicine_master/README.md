# Medicine Master — Android learning app (v1.1.0)

A native Android app built with Kotlin and Jetpack Compose for English-language Clinical Medicine NTA Level 6 study. It is designed to work offline for the bundled learning library and quiz bank.

## Implemented in this release
- Premium-style dashboard and bottom navigation.
- Six subject areas: Clinical Medicine, Forensic Medicine, Obstetrics & Gynaecology, Pharmacology, Paediatrics and Surgery.
- Searchable offline learning library with structured lesson sections.
- Subject filters for all six disciplines and favourites.
- Topic completion and favourites saved locally using Android SharedPreferences.
- Mixed and subject-focused MCQ practice, answer checking, explanations and scoring.
- Progress dashboard with persisted quiz totals and completed topics.
- Educational-use disclaimer.

## Included learning material
- 18 structured topic notes across six subject areas.
- 32 original practice MCQs with answer explanations.

This is an expanded educational MVP, not a complete NTA Level 6 curriculum or an official NACTVET question bank. Content needs review by qualified Tanzanian clinical educators and alignment against the current NTA Level 6 syllabus before formal use. Drug regimens, thresholds and emergency management must be checked against current national guidance.

## Online/offline status
The bundled notes, quiz bank, favourites, topic completion and progress work offline. The project does **not** yet include a cloud backend, user accounts, remote content updates or cross-device synchronisation. Those features require a configured backend and security/privacy design; no fictional online-sync functionality is claimed.

## Build an APK
1. Install Android Studio and JDK 17.
2. Install Android SDK Platform 35 and the matching build tools.
3. Open this `medicine_master` folder in Android Studio.
4. Allow Gradle to sync and download dependencies.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21 and Jetpack Compose Material 3. `minSdk` is 26 (Android 8.0), `targetSdk` is 35.

## Clinical safety
This is an educational tool only. It is not a medical device or clinical decision-support system. Always verify diagnosis and treatment against current Tanzania national guidance, facility protocols and qualified clinical supervision. Emergency management and medication details must not be inferred from this app alone.

## Build from an Android phone using GitHub Actions
This project includes `.github/workflows/android-apk.yml` for a cloud debug build. From a phone, create a GitHub repository, upload the extracted project files (keeping the `.github/workflows` folder), then open the repository's **Actions** tab and run **Build Medicine Master APK**. When the run succeeds, open the run, scroll to **Artifacts**, and download `medicine-master-debug-apk`. Extract the downloaded artifact ZIP to get `app-debug.apk`, then tap the APK and allow installation from that source if Android asks. The workflow builds a debug APK for testing; it is not a signed Play Store release.
