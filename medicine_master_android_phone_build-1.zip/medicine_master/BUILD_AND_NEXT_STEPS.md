# Build and release checklist

## Version 1.1.0
- [x] Android Compose UI and navigation
- [x] Offline lesson library expanded to 18 topics
- [x] Search and filters for all six subjects
- [x] Local topic completion and favourites
- [x] MCQ bank expanded to 32 original questions with explanations
- [x] Mixed and subject-focused practice
- [x] Local progress persistence
- [x] Educational disclaimer

## Remaining before a public/production release
- [ ] Build and test debug/release APK on Android 8+ devices
- [ ] Add automated unit and UI tests; test rotation, low-memory and interrupted sessions
- [ ] Replace SharedPreferences data model with Room and versioned migrations as content grows
- [ ] Expand curriculum coverage against the current official NTA Level 6 syllabus
- [ ] Have notes and questions independently reviewed by qualified clinical educators
- [ ] Add timed mock exams, question randomisation, review of previous attempts and export/backup
- [ ] If online sync is required: choose and configure a backend, authentication, encryption, access controls, privacy policy, deletion/export flows and conflict handling
- [ ] Accessibility review, performance testing and release signing

## Build limitation
No APK has been compiled in this workspace because Android SDK/Gradle build tooling is not available here. The source project is prepared for Android Studio. A successful build and device test are still required before calling it installable or production-ready.
