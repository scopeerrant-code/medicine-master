package com.medicinemaster.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

private val Navy = Color(0xFF102A43)
private val Teal = Color(0xFF12B8A6)
private val Canvas = Color(0xFFF4F7FA)
private val Muted = Color(0xFF627D98)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MedicineMasterApp() } }
}

private data class Topic(val id: String, val subject: String, val title: String, val summary: String, val sections: List<Pair<String,String>>)
private data class Question(val id: String, val subject: String, val prompt: String, val options: List<String>, val answer: Int, val explanation: String)
private data class Subject(val title: String, val subtitle: String, val icon: ImageVector, val tint: Color)

private val subjectList = listOf(
    Subject("Clinical Medicine", "Adult medicine, diagnosis and management", Icons.Default.MedicalServices, Color(0xFFE5F7F4)),
    Subject("Forensic Medicine", "Medico-legal practice and documentation", Icons.Default.Policy, Color(0xFFFFF1E5)),
    Subject("Obstetrics & Gynaecology", "Maternal health, labour and disorders", Icons.Default.PregnantWoman, Color(0xFFF3EAFE)),
    Subject("Pharmacology", "Drug classes, actions and safe use", Icons.Default.Medication, Color(0xFFE8F0FF)),
    Subject("Paediatrics", "Child health and common conditions", Icons.Default.ChildCare, Color(0xFFFFF4D9)),
    Subject("Surgery", "Surgical conditions and patient care", Icons.Default.HealthAndSafety, Color(0xFFE6F4FA))
)

private val topics = listOf(
    Topic("malaria", "Clinical Medicine", "Severe malaria", "Recognition and initial management of severe malaria.", listOf(
        "Definition" to "Severe malaria is malaria with one or more manifestations of vital-organ dysfunction or other markers of severity. It is a medical emergency. Plasmodium falciparum is the usual cause in endemic settings.",
        "Pathophysiology" to "Infected erythrocytes may adhere to vascular endothelium and sequester in small vessels. Microvascular obstruction, inflammation, anaemia, metabolic disturbances and organ dysfunction contribute to severe disease. Hypoglycaemia may result from increased glucose use, reduced hepatic glucose production and quinine-related insulin release.",
        "Clinical features" to "Features include impaired consciousness or coma, repeated convulsions, prostration, respiratory distress or deep breathing, shock, pulmonary oedema, significant bleeding, jaundice with organ dysfunction, severe anaemia, hypoglycaemia, acidosis and renal impairment.",
        "Investigations" to "Urgently check blood glucose, malaria rapid diagnostic test or microscopy, full blood count, renal function, electrolytes, liver tests, lactate or blood gas where available, and assess urine output. Do not delay emergency treatment while awaiting non-essential tests.",
        "Management principles" to "Admit and provide urgent supportive care. Give parenteral artesunate according to current national guidance, then complete a full oral artemisinin-based combination course when able to tolerate oral medicines. Correct hypoglycaemia, manage seizures and fluids carefully, treat severe anaemia when indicated, monitor vital signs and glucose, and investigate alternative or concurrent diagnoses.",
        "Complications and follow-up" to "Possible complications include cerebral malaria, acute kidney injury, pulmonary oedema, severe anaemia, shock and death. Monitor closely and reassess frequently. Follow current Tanzania national malaria guidelines and local protocols."
    )),
    Topic("eclampsia", "Obstetrics & Gynaecology", "Eclampsia", "Seizures in a woman with pre-eclampsia, requiring emergency care.", listOf(
        "Definition" to "Eclampsia is the occurrence of new-onset generalized seizures in a woman with pre-eclampsia, when another cause does not better explain the seizures. It can occur before, during or after childbirth.",
        "Pathophysiology" to "Abnormal placentation and placental release of factors cause widespread maternal endothelial dysfunction and vasoconstriction. Cerebral autoregulation may fail, producing blood-brain barrier disruption, vasogenic oedema and sometimes cerebral ischaemia or haemorrhage. These processes can trigger seizures.",
        "Risk factors and features" to "Risk factors include previous pre-eclampsia, first pregnancy, multiple gestation, chronic hypertension, renal disease, diabetes and autoimmune disease. Warning features may include severe headache, visual disturbance, epigastric or right-upper-quadrant pain, hypertension and proteinuria, but seizures can occur without warning.",
        "Immediate management" to "Call for help; protect the woman from injury, position laterally, maintain airway and oxygenation, assess breathing and circulation, obtain IV access and check glucose. Magnesium sulfate is the anticonvulsant of choice in standard protocols. Treat severe hypertension promptly with an approved agent, monitor reflexes, respiratory rate and urine output, and plan delivery after maternal stabilisation.",
        "Definitive care" to "Delivery is the definitive treatment for the placental cause, but stabilisation comes first. Timing and mode of birth depend on maternal and fetal condition, gestational age and obstetric assessment. Continue close postpartum monitoring because seizures and hypertension may persist or arise after birth.",
        "Complications" to "Maternal complications include aspiration, hypoxia, stroke, pulmonary oedema, renal or hepatic injury, HELLP syndrome and death. Fetal risks include growth restriction, prematurity, placental abruption and stillbirth."
    )),
    Topic("diabetes", "Clinical Medicine", "Diabetes mellitus", "A practical overview of diagnosis and long-term care.", listOf(
        "Definition and types" to "Diabetes mellitus is a group of metabolic disorders characterised by persistent hyperglycaemia due to impaired insulin secretion, insulin action or both. Major types include type 1, type 2 and gestational diabetes.",
        "Pathophysiology" to "In type 1 diabetes, autoimmune destruction of pancreatic beta cells causes absolute insulin deficiency. In type 2 diabetes, insulin resistance and progressive beta-cell dysfunction lead to relative insulin deficiency and increased hepatic glucose output.",
        "Clinical features" to "Classic symptoms are polyuria, polydipsia, polyphagia and unexplained weight loss. Blurred vision, recurrent infections, fatigue and slow wound healing may occur. Some people with type 2 diabetes are asymptomatic.",
        "Diagnosis" to "Diagnosis uses laboratory plasma glucose or HbA1c thresholds in accepted guidelines. In an asymptomatic person, an abnormal result generally requires confirmation on another day. Interpret results using current national and international guidance and consider conditions that affect HbA1c reliability.",
        "Management" to "Management includes individualised nutrition and activity plans, education, cardiovascular risk reduction, glucose monitoring and medicines when indicated. Select treatment according to diabetes type, comorbidities, pregnancy status, renal function, access and current local protocols.",
        "Complications" to "Acute complications include hypoglycaemia, diabetic ketoacidosis and hyperosmolar hyperglycaemic state. Chronic complications include retinopathy, nephropathy, neuropathy and atherosclerotic cardiovascular disease."
    )),
    Topic("fractures", "Surgery", "Fractures: initial assessment", "Systematic assessment and safe early care of suspected fractures.", listOf(
        "Definition" to "A fracture is a break in the continuity of a bone. It may be closed or open, displaced or undisplaced, and may involve the joint surface.",
        "Initial assessment" to "Use an ABCDE approach in trauma. Control life-threatening bleeding, assess the whole patient and identify associated injuries before focusing on the limb. Expose adequately while preventing hypothermia.",
        "Limb examination" to "Inspect deformity, wounds, swelling and skin condition. Palpate gently and assess distal pulses, capillary refill, temperature, sensation and motor function. Document neurovascular findings before and after splinting or manipulation.",
        "Investigations" to "Obtain appropriate radiographs including the joint above and below when indicated. CT may be required for complex or intra-articular injuries. Imaging must not delay resuscitation or urgent treatment of threatened limb perfusion.",
        "Initial management" to "Provide analgesia, cover open wounds with sterile dressings, immobilise in a suitable splint, reassess neurovascular status and arrange urgent orthopaedic review. Open fractures require urgent antibiotics, tetanus assessment and surgical management according to local protocols.",
        "Complications" to "Early complications include haemorrhage, compartment syndrome, neurovascular injury, infection and fat embolism. Late complications include malunion, non-union, avascular necrosis, stiffness and post-traumatic arthritis."
    )),
    Topic("autopsy", "Forensic Medicine", "Medico-legal autopsy principles", "Purpose, documentation and professional safeguards.", listOf(
        "Purpose" to "A medico-legal autopsy is an examination performed under lawful authority to help establish identity, cause of death, and relevant circumstances or manner of death.",
        "Authority and identification" to "Confirm legal authority and follow applicable national law and institutional procedures. Verify identity using approved processes and maintain a clear record of who provided the body and when it was received.",
        "Examination and documentation" to "Record clothing, identifying features, injuries, post-mortem changes and findings systematically. Describe injuries objectively by site, size, shape, colour and other relevant characteristics. Use diagrams and photographs only under authorised procedures.",
        "Evidence handling" to "Maintain chain of custody. Label, seal and document specimens correctly, use appropriate protective equipment and preserve trace evidence according to validated protocols.",
        "Cause and manner of death" to "Cause of death describes the disease or injury initiating the fatal sequence. Manner of death is a classification determined under the relevant legal framework. Distinguish observed facts from interpretation and state limitations clearly.",
        "Professional conduct" to "Maintain confidentiality, impartiality and respect for the deceased and family. Do not alter, omit or speculate beyond the evidence. Refer uncertain findings for specialist review."
    )),
    Topic("antibiotics", "Pharmacology", "Principles of antimicrobial use", "Safe prescribing and antimicrobial stewardship.", listOf(
        "Core principles" to "Choose an antimicrobial based on the likely infection, site, severity, patient factors, local resistance patterns and available guidelines. Antibiotics do not treat viral infections unless there is a bacterial co-infection.",
        "Before prescribing" to "Assess allergy history, pregnancy and breastfeeding, age, weight, renal and hepatic function, interactions, previous antimicrobial exposure and severity. Obtain appropriate cultures before treatment when feasible without delaying urgent therapy.",
        "Selection and review" to "Use the narrowest effective agent, correct dose, route and duration. Review clinical response and microbiology results, then stop, narrow or change therapy as appropriate.",
        "Adverse effects" to "Potential harms include allergy, gastrointestinal effects, drug interactions, organ toxicity, Clostridioides difficile infection and selection of antimicrobial resistance. Counsel patients on important adverse effects and adherence.",
        "Stewardship" to "Avoid unnecessary antibiotics, document indication and planned duration, follow local treatment guidelines and reassess therapy within an appropriate timeframe."
    )),
    Topic("pneumonia", "Clinical Medicine", "Community-acquired pneumonia", "Assessment of acute lower respiratory tract infection.", listOf(
        "Definition" to "Community-acquired pneumonia is an acute infection of the lung parenchyma acquired outside hospital or not associated with recent healthcare exposure as defined by local guidance.",
        "Pathophysiology" to "Pathogens reach the lower respiratory tract by inhalation, aspiration or less commonly haematogenous spread. Inflammatory exudate fills alveoli, impairing gas exchange and causing ventilation-perfusion mismatch.",
        "Clinical features" to "Common features include cough, fever, sputum, pleuritic chest pain, dyspnoea, tachypnoea and focal crackles or bronchial breath sounds. Older adults may present with confusion or functional decline.",
        "Assessment" to "Assess oxygen saturation, respiratory rate, blood pressure, pulse, temperature, mental state and hydration. Chest radiography supports diagnosis when available. Use an accepted severity tool alongside clinical judgement.",
        "Management" to "Provide supportive care and oxygen if hypoxaemic. Select empiric antibiotics according to severity, likely pathogens, allergies and current local guidelines. Review response and investigate complications or alternative diagnoses when indicated.",
        "Complications" to "Complications include respiratory failure, sepsis, parapneumonic effusion, empyema, lung abscess and acute kidney injury."
    )),
    Topic("postpartum", "Obstetrics & Gynaecology", "Postpartum haemorrhage", "Recognition and rapid coordinated response to bleeding after birth.", listOf(
        "Definition" to "Postpartum haemorrhage is excessive bleeding after childbirth. Thresholds and definitions vary by guideline; any bleeding causing haemodynamic compromise requires urgent action.",
        "Causes: the four Ts" to "Tone: uterine atony. Trauma: genital tract tears, uterine rupture or inversion. Tissue: retained placenta or products. Thrombin: coagulopathy.",
        "Recognition" to "Assess visible blood loss alongside pulse, blood pressure, mental state, skin perfusion and urine output. Do not wait for a particular measured blood-loss threshold if the woman is deteriorating.",
        "Immediate response" to "Call for help, initiate the local haemorrhage protocol, resuscitate with appropriate IV access and fluids/blood products, identify the cause, massage an atonic uterus, administer uterotonics and tranexamic acid when indicated by current protocol, and treat trauma or retained tissue.",
        "Ongoing care" to "Monitor vital signs, blood loss, coagulation and response to treatment. Escalate promptly for tamponade, surgery or other definitive interventions when required. Document events and communicate with the woman and family."
    )),
    Topic("dehydration", "Paediatrics", "Dehydration in children", "Assessment and rehydration principles.", listOf(
        "Causes" to "Common causes include acute diarrhoea, vomiting, poor intake, fever and excessive fluid losses. Infants are particularly vulnerable to rapid deterioration.",
        "Assessment" to "Assess general condition, ability to drink, eyes, tears, mucous membranes, skin pinch, pulse, capillary refill and urine output. Classify dehydration using the current integrated childhood illness or national protocol.",
        "Management" to "Use oral rehydration solution for children who can drink and are not in shock, following the recommended plan. Continue breastfeeding and age-appropriate feeding. Severe dehydration or shock requires urgent facility-based IV or other protocol-directed resuscitation and frequent reassessment.",
        "Danger signs" to "Lethargy or unconsciousness, inability to drink, persistent vomiting, convulsions, cold extremities, weak pulse or prolonged capillary refill require urgent assessment and escalation.",
        "Prevention" to "Promote safe water, sanitation, hand hygiene, rotavirus vaccination, breastfeeding and caregiver education. Zinc may be recommended for childhood diarrhoea under national guidance."
    ))

    ,Topic("tuberculosis", "Clinical Medicine", "Pulmonary tuberculosis", "Recognition, investigation, treatment principles and infection prevention.", listOf(
        "Cause and transmission" to "Tuberculosis is caused by Mycobacterium tuberculosis. Pulmonary disease spreads through airborne particles generated by a person with infectious pulmonary or laryngeal TB. Crowding, poor ventilation, HIV and immunosuppression increase risk.",
        "Clinical features" to "Common features include cough, fever, night sweats, weight loss, fatigue, chest pain and sometimes haemoptysis. Symptoms may be atypical in children and people living with HIV.",
        "Diagnosis" to "Use the current national diagnostic algorithm. A WHO-recommended rapid molecular test on an appropriate specimen is generally preferred as an initial test where available. Chest radiography supports assessment but does not alone confirm TB.",
        "Management principles" to "Notify and link confirmed cases to the national TB programme. Use the nationally recommended multidrug regimen, assess for drug resistance and HIV, support adherence, screen contacts and monitor adverse effects. Never use a single anti-TB drug for active disease.",
        "Infection prevention" to "Prompt identification, respiratory hygiene, ventilation, appropriate masks and separation of potentially infectious patients reduce transmission. Follow facility infection-prevention protocols."
    )),
    Topic("heartfailure", "Clinical Medicine", "Heart failure", "Clinical syndrome caused by structural or functional cardiac impairment.", listOf(
        "Definition and causes" to "Heart failure is a clinical syndrome in which cardiac dysfunction causes inadequate output or raised filling pressures. Common causes include hypertension, ischaemic heart disease, valvular disease and cardiomyopathy.",
        "Pathophysiology" to "Reduced forward flow and raised filling pressures activate sympathetic and renin-angiotensin-aldosterone systems. Initially compensatory responses promote vasoconstriction, sodium retention and remodelling, which can worsen congestion and cardiac workload.",
        "Clinical features" to "Typical symptoms include exertional dyspnoea, orthopnoea, paroxysmal nocturnal dyspnoea, fatigue and ankle swelling. Signs may include raised jugular venous pressure, basal crackles, peripheral oedema and displaced apex beat.",
        "Investigations" to "Assess ECG, chest radiograph, renal function, electrolytes, full blood count and natriuretic peptides where available. Echocardiography characterises cardiac structure and ejection fraction. Look for precipitating causes such as infection, arrhythmia or anaemia.",
        "Management principles" to "Treat the cause and precipitants, educate about adherence and follow-up, and use evidence-based therapy appropriate to heart-failure phenotype and local guidelines. Acute pulmonary oedema requires urgent monitored care. Monitor renal function, electrolytes, blood pressure and clinical response."
    )),
    Topic("asthma", "Clinical Medicine", "Bronchial asthma", "Variable respiratory symptoms associated with variable expiratory airflow limitation.", listOf(
        "Mechanism" to "Asthma involves chronic airway inflammation, bronchial hyper-responsiveness and variable airflow obstruction. Triggers may include allergens, viral infections, exercise, smoke and occupational exposures.",
        "Clinical features" to "Episodes of wheeze, breathlessness, chest tightness and cough vary over time and intensity. Symptoms often worsen at night or early morning. A normal examination between episodes does not exclude asthma.",
        "Assessment" to "Assess respiratory rate, speech, work of breathing, oxygenation, pulse and peak expiratory flow when feasible. Spirometry demonstrating variable expiratory airflow limitation supports diagnosis. Identify life-threatening features and do not delay emergency treatment.",
        "Management principles" to "Use an inhaled corticosteroid-containing treatment strategy in accordance with current asthma guidance; avoid relying on short-acting bronchodilator alone. Check inhaler technique, adherence, triggers and written action plan. Acute severe attacks require urgent protocol-based treatment and reassessment.",
        "Prevention" to "Reduce tobacco-smoke exposure, address relevant triggers, ensure access to prescribed controller treatment and review control regularly."
    )),
    Topic("hypertension", "Clinical Medicine", "Hypertension", "Persistent elevation of arterial blood pressure and prevention of target-organ damage.", listOf(
        "Definition and risk" to "Hypertension is persistently elevated blood pressure. Diagnosis requires correctly performed measurements and confirmation according to current national or international guidance, except when urgent severe disease requires immediate action.",
        "Assessment" to "Use a validated device and correct cuff size after rest. Assess cardiovascular risk, medication and substance use, family history and evidence of kidney, retinal, cardiac or cerebrovascular damage. Investigate secondary causes when indicated.",
        "Complications" to "Long-term uncontrolled hypertension increases risk of stroke, heart failure, coronary disease, chronic kidney disease, retinopathy and peripheral vascular disease.",
        "Management" to "Lifestyle measures include reduced dietary salt, healthy weight, regular physical activity, moderation of alcohol and tobacco cessation. Select antihypertensive medicines according to comorbidities, pregnancy status, renal function and current guidance. Arrange follow-up and monitor adverse effects.",
        "Hypertensive emergency" to "Severe blood pressure elevation with acute target-organ injury is an emergency requiring hospital assessment and carefully monitored treatment. Avoid precipitous unsupervised blood-pressure reduction."
    )),
    Topic("anaemia", "Clinical Medicine", "Approach to anaemia", "Systematic classification and investigation of reduced haemoglobin.", listOf(
        "Definition" to "Anaemia is a haemoglobin concentration below the appropriate reference threshold for age, sex and pregnancy status. Interpret results using local laboratory ranges and clinical context.",
        "Classification" to "Mean corpuscular volume helps classify anaemia as microcytic, normocytic or macrocytic. Causes include iron deficiency, chronic inflammation, haemolysis, blood loss, nutritional deficiency, marrow disease and inherited haemoglobin disorders.",
        "Clinical features" to "Symptoms may include fatigue, reduced exercise tolerance, dizziness, palpitations and breathlessness. Signs include pallor and tachycardia; severe or chronic anaemia may cause cardiac strain.",
        "Investigations" to "Start with full blood count and red-cell indices, reticulocyte count and blood film. Further tests may include ferritin and iron studies, renal function, vitamin B12, folate, haemolysis tests, malaria testing or evaluation for blood loss according to context.",
        "Management" to "Treat the underlying cause. Replace documented deficiencies, control bleeding and manage infection or chronic disease. Transfusion decisions depend on haemodynamic status, symptoms, comorbidities and current transfusion guidance, not haemoglobin alone."
    )),
    Topic("acute-kidney-injury", "Clinical Medicine", "Acute kidney injury", "Acute decline in kidney function requiring prompt identification of cause.", listOf(
        "Definition and categories" to "Acute kidney injury is an abrupt decline in kidney function identified by changes in serum creatinine and/or urine output using accepted criteria. Causes are commonly grouped as pre-renal, intrinsic renal and post-renal.",
        "Causes" to "Pre-renal causes include volume depletion and poor perfusion; intrinsic causes include tubular injury, glomerulonephritis and interstitial nephritis; post-renal causes include urinary obstruction.",
        "Assessment" to "Review fluid losses, intake, medicines and systemic illness. Assess volume status, blood pressure, urine output and bladder retention. Check creatinine, urea, electrolytes, urinalysis and imaging when obstruction is suspected.",
        "Management principles" to "Treat the cause, restore perfusion when appropriate, stop or adjust nephrotoxic and renally cleared medicines, monitor fluid balance and electrolytes, and relieve obstruction. Avoid indiscriminate fluid loading, especially with overload or heart failure.",
        "Urgent escalation" to "Seek urgent specialist or hospital care for refractory hyperkalaemia, severe acidosis, pulmonary oedema, uraemic complications, rapidly worsening renal function or suspected obstruction requiring intervention."
    )),
    Topic("familyplanning", "Obstetrics & Gynaecology", "Contraception counselling", "Person-centred counselling on effective contraceptive choices.", listOf(
        "Counselling approach" to "Provide respectful, confidential, non-coercive counselling. Explore reproductive goals, preferences, medical history, breastfeeding, postpartum status, medicines and concerns. The client makes the informed choice.",
        "Method categories" to "Methods include condoms, pills, injectables, implants, intrauterine contraception, fertility-awareness methods and permanent methods. Effectiveness, duration, reversibility and side-effect profiles differ.",
        "Safety" to "Assess medical eligibility using current WHO and national criteria. Consider contraindications, drug interactions, postpartum timing and symptoms requiring evaluation before method initiation.",
        "STI prevention" to "Condoms reduce transmission of many sexually transmitted infections and can be used with another contraceptive method for dual protection. Most other contraceptive methods do not prevent STIs.",
        "Follow-up" to "Explain expected side effects, warning symptoms, when to return, how to switch or discontinue and where to obtain help. Respect the right to change or decline a method."
    )),
    Topic("woundcare", "Surgery", "Wound assessment and care", "Basic principles of safe wound assessment, cleaning and follow-up.", listOf(
        "Initial assessment" to "Assess mechanism, time, contamination, bleeding, pain, depth, tissue viability and possible foreign body. Examine distal circulation, sensation and movement where relevant. Consider tendon, nerve, vessel, joint or bone injury.",
        "Immediate care" to "Control haemorrhage with direct pressure where appropriate, provide analgesia, irrigate contaminated wounds and protect the wound. Escalate uncontrolled bleeding, deep injury, bites, open fractures or suspected neurovascular damage.",
        "Infection prevention" to "Use clean or sterile technique appropriate to the procedure, assess tetanus immunisation and exposure risk, and prescribe antibiotics only when indicated by wound type and local guidance.",
        "Closure decisions" to "Choose closure based on wound age, contamination, tissue viability, location and risk. Some contaminated wounds require delayed closure or specialist assessment. Do not close over suspected infection or retained foreign material.",
        "Documentation and review" to "Document findings, neurovascular status, cleaning, closure, immunisation advice and consent. Give clear wound-care instructions and return precautions for increasing pain, redness, swelling, discharge, fever or reduced function."
    )),
    Topic("hiv", "Clinical Medicine", "HIV: clinical assessment and care", "Principles of testing, linkage, antiretroviral therapy and prevention.", listOf(
        "Transmission and prevention" to "HIV can be transmitted through sexual exposure, blood exposure and vertical transmission during pregnancy, birth or breastfeeding. Prevention includes condoms, sterile injecting equipment, PrEP or PEP when indicated, and effective ART.",
        "Testing" to "Use the national HIV testing algorithm with informed consent, confidentiality and appropriate pre- and post-test counselling. A reactive screening result must be resolved according to the confirmatory national algorithm before diagnosis is assigned.",
        "Clinical assessment" to "Assess symptoms, opportunistic infections, TB, nutritional status, pregnancy, mental and social support, medicines and baseline investigations according to national guidance.",
        "Treatment principles" to "Offer prompt linkage to lifelong antiretroviral therapy under national guidelines. Support adherence, monitor viral load and adverse effects, review drug interactions and manage opportunistic infections. Do not interrupt ART without clinical advice.",
        "Prevention and follow-up" to "Undetectable viral load on sustained effective ART prevents sexual transmission (U=U). Continue routine monitoring, prevention counselling, partner services and screening for TB and other relevant conditions."
    ))

)

private val questions = listOf(
    Question("q1","Clinical Medicine","Which test should be checked immediately in a patient with suspected severe malaria and altered consciousness?",listOf("Blood glucose","Serum cholesterol","Lipid profile","Skin test"),0,"Hypoglycaemia is a reversible, life-threatening cause of altered consciousness and can accompany severe malaria. Check glucose promptly."),
    Question("q2","Clinical Medicine","The main mechanism contributing to cerebral malaria includes:",listOf("Excess insulin alone","Sequestration of parasitised erythrocytes in microvasculature","Vitamin deficiency","Increased bone formation"),1,"Adherence and sequestration of infected erythrocytes, together with inflammation and endothelial dysfunction, contribute to microvascular injury."),
    Question("q3","Obstetrics & Gynaecology","The anticonvulsant of choice for eclampsia in standard protocols is:",listOf("Diazepam as routine first choice","Magnesium sulfate","Phenytoin for all cases","Haloperidol"),1,"Magnesium sulfate is the preferred medicine for prevention and treatment of eclamptic seizures in standard obstetric protocols."),
    Question("q4","Obstetrics & Gynaecology","The definitive treatment for the placental cause of pre-eclampsia/eclampsia is:",listOf("Long-term antibiotics","Delivery of the placenta","Diuretics alone","Bed rest alone"),1,"Delivery removes the placenta, the source of the pathologic process. Maternal stabilisation is required before delivery planning."),
    Question("q5","Clinical Medicine","Which combination is classically associated with diabetes mellitus?",listOf("Polyuria, polydipsia, polyphagia","Cough, haemoptysis, rash","Jaundice, pruritus, ear pain","Bradycardia, constipation, deafness"),0,"The classic symptoms are increased urination, thirst and hunger; unexplained weight loss may also occur."),
    Question("q6","Surgery","In a limb fracture, distal neurovascular status should be documented:",listOf("Only at discharge","Before and after splinting or manipulation","Only if pain is absent","Never"),1,"Document pulses, perfusion, sensation and motor function before and after interventions to detect deterioration."),
    Question("q7","Forensic Medicine","The chain of custody is primarily used to:",listOf("Improve wound healing","Preserve integrity and traceability of evidence","Determine blood pressure","Replace consent"),1,"A documented chain of custody records who collected, handled, transferred and stored evidence."),
    Question("q8","Pharmacology","A key antimicrobial stewardship action is to:",listOf("Use broad-spectrum drugs indefinitely","Review therapy and narrow or stop when appropriate","Treat every viral infection with antibiotics","Ignore culture results"),1,"Reviewing therapy against clinical response and microbiology reduces avoidable exposure and antimicrobial resistance."),
    Question("q9","Clinical Medicine","Alveolar exudate in pneumonia primarily impairs:",listOf("Gas exchange","Bone growth","Vision","Hearing"),0,"Inflammatory fluid in alveoli interferes with ventilation and oxygen transfer, causing impaired gas exchange."),
    Question("q10","Obstetrics & Gynaecology","The four Ts of postpartum haemorrhage include tone, trauma, tissue and:",listOf("Temperature","Thrombin","Thyroid","Thirst"),1,"The four Ts are tone, trauma, tissue and thrombin (coagulation disorders)."),
    Question("q11","Paediatrics","A child with lethargy, inability to drink and a weak pulse needs:",listOf("Routine home observation only","Urgent assessment and escalation","No further assessment","A high-fibre diet only"),1,"These are danger signs that may indicate severe dehydration, shock or serious illness and require urgent care."),
    Question("q12","Clinical Medicine","Which is an acute complication of diabetes?",listOf("Diabetic ketoacidosis","Cataract only","Chronic neuropathy only","Peripheral arterial disease only"),0,"Diabetic ketoacidosis is an acute metabolic emergency. Other acute complications include hypoglycaemia and hyperosmolar hyperglycaemic state.")

    ,Question("q13","Clinical Medicine","Which specimen-based test is generally preferred as an initial diagnostic test for presumptive pulmonary TB where available?",listOf("WHO-recommended rapid molecular test","Widal test","Urine glucose only","ECG"),0,"A WHO-recommended rapid molecular assay can detect TB and some drug resistance rapidly. Follow the current national diagnostic algorithm."),
    Question("q14","Clinical Medicine","A common symptom of left-sided heart failure is:",listOf("Orthopnoea","Polyuria only","Ear discharge","Photophobia"),0,"Raised pulmonary venous pressure causes breathlessness, orthopnoea and paroxysmal nocturnal dyspnoea."),
    Question("q15","Clinical Medicine","Which investigation characterises cardiac structure and ejection fraction in suspected heart failure?",listOf("Echocardiography","Urine dipstick alone","Skin prick test","Stool microscopy"),0,"Echocardiography evaluates cardiac structure, valves and systolic function."),
    Question("q16","Clinical Medicine","Asthma is typically characterised by:",listOf("Variable respiratory symptoms and variable airflow limitation","Fixed airway obstruction in every patient","Alveolar pus as the defining feature","Pleural fluid in all cases"),0,"Asthma causes variable symptoms and variable expiratory airflow limitation due to airway inflammation and hyper-responsiveness."),
    Question("q17","Clinical Medicine","Which medicine class is central to reducing airway inflammation in asthma controller treatment?",listOf("Inhaled corticosteroids","Antacids","Antifungals for everyone","Loop diuretics"),0,"Inhaled corticosteroid-containing treatment is central to reducing asthma exacerbation risk. Follow current asthma guidance."),
    Question("q18","Clinical Medicine","The correct first step when measuring blood pressure is to:",listOf("Use a suitable cuff and allow the patient to rest","Measure over clothing with any cuff","Ask the patient to exercise during measurement","Use only the smallest cuff"),0,"Correct positioning, rest, a validated device and an appropriate cuff size improve measurement accuracy."),
    Question("q19","Clinical Medicine","Which long-term complication is associated with uncontrolled hypertension?",listOf("Stroke","Appendicitis","Otitis externa","Acute tonsillitis"),0,"Persistent hypertension increases the risk of stroke, heart failure, coronary disease and kidney disease."),
    Question("q20","Clinical Medicine","A low mean corpuscular volume most commonly directs the clinician to consider:",listOf("Microcytic anaemia such as iron deficiency","Macrocytosis only","Thrombocytopenia only","Leukocytosis"),0,"A low MCV indicates microcytosis. Iron deficiency and thalassaemia are important causes, among others."),
    Question("q21","Clinical Medicine","Which test is useful as an initial measure of the marrow response to anaemia?",listOf("Reticulocyte count","Serum sodium only","ECG","Chest circumference"),0,"The reticulocyte count helps distinguish reduced production from an appropriate marrow response to blood loss or haemolysis."),
    Question("q22","Clinical Medicine","Which is a post-renal cause of acute kidney injury?",listOf("Urinary tract obstruction","Severe diarrhoeal dehydration","Acute tubular injury","Glomerulonephritis"),0,"Obstruction to urine outflow is a post-renal cause. Prompt recognition and relief may preserve kidney function."),
    Question("q23","Clinical Medicine","In a patient with acute kidney injury, which electrolyte abnormality can cause life-threatening arrhythmia?",listOf("Hyperkalaemia","Mild isolated hypochloraemia","Low phosphate only","Low albumin"),0,"Hyperkalaemia can disrupt cardiac conduction and cause fatal arrhythmias; assess and treat urgently using local emergency protocols."),
    Question("q24","Obstetrics & Gynaecology","Good contraceptive counselling should be:",listOf("Voluntary, confidential and non-coercive","Focused on one method for every client","Without discussion of side effects","Given only after method selection"),0,"Person-centred counselling supports informed choice and respects autonomy, privacy and preferences."),
    Question("q25","Obstetrics & Gynaecology","Which contraceptive method also reduces transmission of many sexually transmitted infections?",listOf("Condoms","Implants","Injectables","Copper IUD"),0,"Condoms provide STI risk reduction and can be combined with another method for dual protection."),
    Question("q26","Surgery","After a limb injury, distal neurovascular assessment should include:",listOf("Perfusion, sensation and motor function","Hair colour only","Appetite and sleep","Visual acuity"),0,"Document distal circulation, sensation and movement, including before and after splinting or manipulation."),
    Question("q27","Surgery","A wound with suspected tendon or nerve injury requires:",listOf("Careful assessment and appropriate urgent referral","Immediate home closure without examination","No documentation","Routine topical cream only"),0,"Deep structural injury needs careful examination and escalation to an appropriately skilled clinician."),
    Question("q28","Clinical Medicine","A reactive HIV screening test should be followed by:",listOf("The confirmatory national testing algorithm","Immediate lifelong diagnosis without further testing","A malaria test only","No further action"),0,"HIV diagnosis must follow the validated national algorithm, with consent, confidentiality and counselling."),
    Question("q29","Clinical Medicine","What does U=U mean in HIV care?",listOf("Sustained undetectable viral load prevents sexual transmission","HIV is cured after one dose","ART can always be stopped","Testing is no longer useful"),0,"People who maintain an undetectable viral load on effective ART do not sexually transmit HIV. ART must continue as prescribed."),
    Question("q30","Paediatrics","In a child with diarrhoea who can drink and has no shock, a key treatment is:",listOf("Oral rehydration solution according to the recommended plan","Withholding all fluids","Routine antibiotics for every case","Carbonated drinks only"),0,"ORS replaces water and electrolytes. Continue breastfeeding and feeding, and assess for danger signs and severe dehydration."),
    Question("q31","Forensic Medicine","Why should every transfer of forensic evidence be documented?",listOf("To maintain chain of custody and traceability","To make evidence anonymous","To avoid consent","To replace laboratory analysis"),0,"A documented chain of custody records handling and transfer, helping demonstrate evidence integrity."),
    Question("q32","Pharmacology","Before prescribing a medicine, a clinician should routinely check:",listOf("Allergies, current medicines and relevant patient factors","Only the brand colour","The patient's favourite food only","Nothing if the drug is common"),0,"Medication reconciliation, allergies, comorbidities, pregnancy status where relevant, interactions and organ function support safer prescribing.")

)

@Composable
fun MedicineMasterApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("medicine_master", Context.MODE_PRIVATE) }
    var completed by remember { mutableStateOf(loadSet(prefs, "completed")) }
    var favourites by remember { mutableStateOf(loadSet(prefs, "favourites")) }
    var attempts by remember { mutableIntStateOf(prefs.getInt("attempts", 0)) }
    var correctTotal by remember { mutableIntStateOf(prefs.getInt("correct", 0)) }
    var selectedTab by remember { mutableStateOf("Home") }
    var chosenTopic by remember { mutableStateOf<Topic?>(null) }
    var quizSubject by remember { mutableStateOf<String?>(null) }
    var quizRunning by remember { mutableStateOf(false) }
    var quizIndex by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var selectedAnswer by remember { mutableIntStateOf(-1) }
    var answered by remember { mutableStateOf(false) }
    var lastResult by remember { mutableStateOf<Pair<Int,Int>?>(null) }
    fun persistSet(key: String, set: Set<String>) { prefs.edit().putStringSet(key, set).apply() }
    MaterialTheme(colorScheme = lightColorScheme(primary = Teal, secondary = Navy, background = Canvas, surface = Color.White)) {
        Scaffold(containerColor = Canvas, bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("Home" to Icons.Default.Home, "Learning" to Icons.Default.MenuBook, "Exams" to Icons.Default.Quiz, "Progress" to Icons.Default.Insights, "Profile" to Icons.Default.Person).forEach { (label, icon) ->
                    NavigationBarItem(selected = selectedTab == label && chosenTopic == null && !quizRunning, onClick = { selectedTab = label; chosenTopic = null; quizRunning = false }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Teal, indicatorColor = Teal.copy(.12f), selectedTextColor = Navy))
                }
            }
        }) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when {
                    chosenTopic != null -> TopicReader(chosenTopic!!, completed.contains(chosenTopic!!.id), favourites.contains(chosenTopic!!.id), onBack = { chosenTopic = null }, onComplete = { completed = completed + it; persistSet("completed", completed) }, onFavourite = { id -> favourites = if (favourites.contains(id)) favourites - id else favourites + id; persistSet("favourites", favourites) })
                    quizRunning -> QuizScreen(questions.filter { quizSubject == null || it.subject == quizSubject }, quizIndex, selectedAnswer, answered, score, onChoose = { selectedAnswer = it }, onSubmit = { if (!answered) { answered = true; if (selectedAnswer == questionsFor(quizSubject)[quizIndex].answer) score++ } }, onNext = {
                        if (quizIndex + 1 < questionsFor(quizSubject).size) { quizIndex++; selectedAnswer = -1; answered = false }
                        else { attempts++; correctTotal += score; prefs.edit().putInt("attempts", attempts).putInt("correct", correctTotal).apply(); lastResult = score to questionsFor(quizSubject).size; quizRunning = false; selectedTab = "Exams" }
                    })
                    else -> when (selectedTab) {
                        "Home" -> HomeScreen(completed.size, attempts, onLearn = { selectedTab = "Learning" }, onQuiz = { quizSubject = null; quizRunning = true; quizIndex = 0; score = 0; selectedAnswer = -1; answered = false })
                        "Learning" -> LearningScreen(completed, favourites, onTopic = { chosenTopic = it })
                        "Exams" -> ExamsScreen(lastResult, onStart = { subject -> quizSubject = subject; quizRunning = true; quizIndex = 0; score = 0; selectedAnswer = -1; answered = false })
                        "Progress" -> ProgressScreen(completed.size, topics.size, attempts, correctTotal, favourites.size)
                        else -> ProfileScreen()
                    }
                }
            }
        }
    }
}

private fun questionsFor(subject: String?): List<Question> = questions.filter { subject == null || it.subject == subject }
private fun loadSet(prefs: android.content.SharedPreferences, key: String): Set<String> = prefs.getStringSet(key, emptySet())?.toSet() ?: emptySet()

@Composable private fun HomeScreen(done: Int, attempts: Int, onLearn: () -> Unit, onQuiz: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("MEDICINE MASTER", color = Navy, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, letterSpacing = 1.sp); Text("Your clinical learning companion · NTA Level 6", color = Muted, fontSize = 12.sp) }
        item { Column(Modifier.fillMaxWidth().background(Navy, RoundedCornerShape(24.dp)).padding(22.dp)) { Text("LEARN • PRACTISE • PROGRESS", color = Teal, fontWeight = FontWeight.Bold, fontSize = 11.sp); Spacer(Modifier.height(10.dp)); Text("Build clinical confidence.\nOne topic at a time.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp); Spacer(Modifier.height(8.dp)); Text("Structured study notes and knowledge checks, available offline.", color = Color(0xFFD9E2EC), fontSize = 13.sp); Spacer(Modifier.height(16.dp)); Button(onClick = onLearn, colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Text("Explore learning library", color = Navy) } } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { StatCard("$done/${topics.size}", "Topics completed", Icons.Default.MenuBook, Modifier.weight(1f)); StatCard("$attempts", "Quizzes taken", Icons.Default.Quiz, Modifier.weight(1f)) } }
        item { SectionTitle("Study subjects", "Six core learning areas") }
        items(subjectList) { SubjectCard(it) { onLearn() } }
        item { Button(onClick = onQuiz, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Icon(Icons.Default.Bolt, null, tint = Navy); Spacer(Modifier.width(8.dp)); Text("Start mixed practice quiz", color = Navy, fontWeight = FontWeight.Bold) } }
        item { Disclaimer() }
    }
}

@Composable private fun LearningScreen(done: Set<String>, favourites: Set<String>, onTopic: (Topic) -> Unit) {
    var query by remember { mutableStateOf("") }; var filter by remember { mutableStateOf("All") }
    val filtered = topics.filter { (filter == "All" || it.subject == filter || (filter == "Favourites" && favourites.contains(it.id))) && (query.isBlank() || it.title.contains(query, true) || it.subject.contains(query, true) || it.summary.contains(query, true)) }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(20.dp)) { Text("Learning library", color = Navy, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Offline notes organised by subject", color = Muted, fontSize = 13.sp); Spacer(Modifier.height(12.dp)); OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search topics") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(14.dp)) }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("All", "Clinical Medicine", "Forensic Medicine", "Obstetrics & Gynaecology", "Pharmacology", "Paediatrics", "Surgery", "Favourites").forEach { f -> FilterChip(selected = filter == f, onClick = { filter = f }, label = { Text(if (f == "Obstetrics & Gynaecology") "OB/GYN" else f, fontSize = 10.sp) }) } }
        LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { items(filtered) { t -> Card(Modifier.fillMaxWidth().clickable { onTopic(t) }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(15.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Text(t.subject.uppercase(), color = Teal, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); if (done.contains(t.id)) Icon(Icons.Default.CheckCircle, null, tint = Teal, modifier = Modifier.size(18.dp)); if (favourites.contains(t.id)) Icon(Icons.Default.Bookmark, null, tint = Navy, modifier = Modifier.size(18.dp)) }; Spacer(Modifier.height(5.dp)); Text(t.title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text(t.summary, color = Muted, fontSize = 12.sp) } } } }
    }
}

@Composable private fun TopicReader(topic: Topic, isDone: Boolean, isFavourite: Boolean, onBack: () -> Unit, onComplete: (String) -> Unit, onFavourite: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Navy) }; Column(Modifier.weight(1f)) { Text(topic.subject, color = Teal, fontSize = 10.sp, fontWeight = FontWeight.Bold); Text(topic.title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp) }; IconButton(onClick = { onFavourite(topic.id) }) { Icon(if (isFavourite) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null, tint = Teal) } }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text(topic.summary, color = Muted, fontSize = 14.sp) }
            items(topic.sections) { (heading, body) -> Column { Text(heading, color = Navy, fontWeight = FontWeight.Bold, fontSize = 17.sp); Spacer(Modifier.height(5.dp)); Text(body, color = Color(0xFF334E68), fontSize = 14.sp, lineHeight = 22.sp) } }
            item { Text("Study reminder: confirm clinical decisions against current national guidelines, facility protocols and senior clinical advice.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp) }
        }
        Button(onClick = { onComplete(topic.id); onBack() }, enabled = !isDone, modifier = Modifier.fillMaxWidth().padding(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Icon(Icons.Default.CheckCircle, null, tint = Navy); Spacer(Modifier.width(8.dp)); Text(if (isDone) "Topic completed" else "Mark topic as completed", color = Navy) }
    }
}

@Composable private fun ExamsScreen(last: Pair<Int,Int>?, onStart: (String?) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Examination centre", color = Navy, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Practise with explanations and instant scoring", color = Muted, fontSize = 13.sp) }
        if (last != null) item { Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE5F7F4))) { Text("Last result: ${last.first}/${last.second} correct", Modifier.padding(16.dp), color = Navy, fontWeight = FontWeight.Bold) } }
        item { ExamCard("Mixed practice", "All subjects · ${questions.size} questions", Icons.Default.Bolt) { onStart(null) } }
        subjectList.forEach { s -> item { ExamCard(s.title, "Topic-focused questions", s.icon) { onStart(s.title) } } }
        item { Text("Questions are educational practice items, not official NACTVET examination papers.", color = Muted, fontSize = 11.sp) }
    }
}

@Composable private fun QuizScreen(list: List<Question>, index: Int, selected: Int, answered: Boolean, score: Int, onChoose: (Int) -> Unit, onSubmit: () -> Unit, onNext: () -> Unit) {
    val q = list[index]
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("PRACTICE QUIZ", color = Teal, fontWeight = FontWeight.Bold, fontSize = 11.sp); Spacer(Modifier.height(6.dp)); Text("Question ${index + 1} of ${list.size}", color = Muted, fontSize = 12.sp); LinearProgressIndicator(progress = { (index + 1).toFloat() / list.size }, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), color = Teal)
        Text(q.subject.uppercase(), color = Teal, fontSize = 10.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(10.dp)); Text(q.prompt, color = Navy, fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 27.sp); Spacer(Modifier.height(18.dp))
        q.options.forEachIndexed { i, option -> Card(Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable(enabled = !answered) { onChoose(i) }, colors = CardDefaults.cardColors(containerColor = when { answered && i == q.answer -> Color(0xFFE1F5EC); answered && i == selected -> Color(0xFFFFE8E8); selected == i -> Color(0xFFE8F0FF); else -> Color.White }), shape = RoundedCornerShape(14.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Text("${'A' + i}.", color = Teal, fontWeight = FontWeight.Bold); Spacer(Modifier.width(10.dp)); Text(option, color = Navy, fontSize = 14.sp, modifier = Modifier.weight(1f)); if (answered && i == q.answer) Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF23865B)) } } }
        if (answered) { Spacer(Modifier.height(8.dp)); Text(if (selected == q.answer) "Correct" else "Not quite", color = if (selected == q.answer) Color(0xFF23865B) else Color(0xFFB54747), fontWeight = FontWeight.Bold); Text(q.explanation, color = Color(0xFF334E68), fontSize = 13.sp, lineHeight = 19.sp) }
        Spacer(Modifier.weight(1f)); Button(onClick = if (answered) onNext else onSubmit, enabled = answered || selected >= 0, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Teal)) { Text(if (!answered) "Check answer" else if (index == list.size - 1) "Finish quiz" else "Next question", color = Navy, fontWeight = FontWeight.Bold) }
    }
}

@Composable private fun ProgressScreen(done: Int, total: Int, attempts: Int, correct: Int, favourites: Int) {
    Column(Modifier.fillMaxSize().padding(20.dp)) { Text("My progress", color = Navy, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("Your learning activity is saved on this device", color = Muted, fontSize = 12.sp); Spacer(Modifier.height(20.dp)); Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)) { Text("Topics completed", color = Navy, fontWeight = FontWeight.Bold); Spacer(Modifier.height(10.dp)); LinearProgressIndicator(progress = { if (total == 0) 0f else done.toFloat() / total }, modifier = Modifier.fillMaxWidth().height(9.dp), color = Teal); Spacer(Modifier.height(8.dp)); Text("$done of $total topics · ${if (total == 0) 0 else done * 100 / total}%", color = Muted, fontSize = 12.sp) } }; Spacer(Modifier.height(12.dp)); StatCard("$attempts", "Quizzes completed", Icons.Default.Quiz, Modifier.fillMaxWidth()); Spacer(Modifier.height(10.dp)); StatCard("$correct", "Correct answers across quizzes", Icons.Default.CheckCircle, Modifier.fillMaxWidth()); Spacer(Modifier.height(10.dp)); StatCard("$favourites", "Saved favourite topics", Icons.Default.Bookmark, Modifier.fillMaxWidth()) }
}

@Composable private fun ProfileScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) { Text("Profile & settings", color = Navy, fontSize = 25.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(20.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(56.dp).background(Color(0xFFE5F7F4), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Teal, modifier = Modifier.size(30.dp)) }; Spacer(Modifier.width(12.dp)); Column { Text("Medical student", color = Navy, fontWeight = FontWeight.Bold); Text("NTA Level 6 · English", color = Muted, fontSize = 12.sp) } }; Spacer(Modifier.height(22.dp)); SettingRow("Study content", "English language · Offline library"); SettingRow("Progress storage", "Saved locally on this device"); SettingRow("Internet access", "Not required for included notes and quizzes"); SettingRow("App version", "1.1.0 · Expanded offline learning release"); Spacer(Modifier.height(20.dp)); Disclaimer() }
}

@Composable private fun SubjectCard(s: Subject, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(44.dp).background(s.tint, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Icon(s.icon, null, tint = Navy) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(s.title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text(s.subtitle, color = Muted, fontSize = 11.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Teal) } } }
@Composable private fun ExamCard(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Teal, modifier = Modifier.size(25.dp)); Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) { Text(title, color = Navy, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 11.sp) }; Icon(Icons.Default.PlayArrow, null, tint = Teal) } } }
@Composable private fun SectionTitle(title: String, subtitle: String) { Column { Text(title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(subtitle, color = Muted, fontSize = 11.sp) } }
@Composable private fun StatCard(value: String, label: String, icon: ImageVector, modifier: Modifier = Modifier) { Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(14.dp)) { Icon(icon, null, tint = Teal, modifier = Modifier.size(19.dp)); Spacer(Modifier.height(7.dp)); Text(value, color = Navy, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp); Text(label, color = Muted, fontSize = 10.sp, lineHeight = 13.sp) } } }
@Composable private fun SettingRow(title: String, value: String) { Column(Modifier.fillMaxWidth().padding(vertical = 12.dp)) { Text(title, color = Navy, fontWeight = FontWeight.SemiBold, fontSize = 14.sp); Text(value, color = Muted, fontSize = 12.sp) }; HorizontalDivider(color = Color(0xFFE5EAF0)) }
@Composable private fun Disclaimer() { Text("EDUCATIONAL USE ONLY. This app supports learning and examination practice. It is not a clinical decision-support tool and does not replace current national guidelines, local protocols, supervision or professional judgement. Drug doses and emergency care must be checked against authoritative current guidance.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp) }
